# The Podcast - Naomi & Yael

A Pen created on CodePen.

Original URL: [https://codepen.io/Yael-Shifman/pen/YPXVQQP](https://codepen.io/Yael-Shifman/pen/YPXVQQP).

